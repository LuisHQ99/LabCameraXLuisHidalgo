package cr.ac.ucr.cameraxapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_pantalla_formulario.*

class PantallaFormulario : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pantalla_formulario)
        click_botonEnviarInfo()
        click_botonEnviarFoto()
    }

    fun click_botonEnviarInfo(){
        enviarInfoBtn.setOnClickListener(){
           // val to = correoText.getText().toString()
            val to = "reporte.covid-19@gmail.com"
            val subject = nombreText.getText().toString()
            val tos = nombreText.getText().toString()
            var message = ""
            if(switchFiebre.isChecked()) {
                message = message + "Fiebre, "
            }
            if(switchTos.isChecked()) {
                message = message + "Tos, "
            }
            if(switchMigrana.isChecked()) {
                message = message + "Migraña, "
            }
            if(switchCansancio.isChecked()) {
                message = message + "Cansancio, "
            }
            if(switchOlfato.isChecked()) {
                message = message + "Perdida del olfato, "
            }
            if(switchGusto.isChecked()) {
                message = message + " Perdida del gusto "
            }

            val intent = Intent(Intent.ACTION_SEND)
            val addressees = arrayOf(to)
            intent.putExtra(Intent.EXTRA_EMAIL, addressees)
            intent.putExtra(Intent.EXTRA_SUBJECT, subject)
            intent.putExtra(Intent.EXTRA_TEXT, message)
            intent.setType("message/rfc822")
            startActivity(Intent.createChooser(intent, "Send Email using:"));

            Toast.makeText(applicationContext, "enviar info", Toast.LENGTH_SHORT).show()
        }
        }

    fun click_botonEnviarFoto(){
        enviarFotoBtn.setOnClickListener(){
               val ventanaFoto: Intent = Intent(applicationContext, MainActivity::class.java) //le asignamos la activity
              startActivity(ventanaFoto)
            Toast.makeText(applicationContext, "enviar foto", Toast.LENGTH_SHORT).show()
        }
    }
}
