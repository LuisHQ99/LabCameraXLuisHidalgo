package cr.ac.ucr.cameraxapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_pantalla_formulario.*
import kotlinx.android.synthetic.main.activity_visualizar_foto.*


class VisualizarFoto : AppCompatActivity() {
private var rutaImagen = ""
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_visualizar_foto)
      //  val imageview: TextView = findViewById(R.id.textView3)
       // val ss:String = intent.getStringExtra("samplename")
      //  imageview.setText(ss)

        var bundle :Bundle ?=intent.extras
        var message = bundle!!.getString("samplename") // 1
        //var strUser: String = intent.getStringExtra("value") // 2

        val imageview: TextView = findViewById(R.id.textView3)
        rutaImagen = message.toString()
        imageview.setText("Ruta imagen: "+message.toString())

        //Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
        click_botonEnviarFoto()
        click_botonGuardar()
    }
    fun click_botonEnviarFoto(){
        buttonEnviar.setOnClickListener(){
            // val to = correoText.getText().toString()
            val to = "reporte.covid-19@gmail.com"
            val subject = "imagen reporte"
            var message = rutaImagen
            val intent = Intent(Intent.ACTION_SEND)
            val addressees = arrayOf(to)
            intent.putExtra(Intent.EXTRA_EMAIL, addressees)
            intent.putExtra(Intent.EXTRA_SUBJECT, subject)
            intent.putExtra(Intent.EXTRA_TEXT, message)
            intent.setType("message/rfc822")
            startActivity(Intent.createChooser(intent, "Send Email using:"));

            //Toast.makeText(applicationContext, "enviar info", Toast.LENGTH_SHORT).show()
        }
    }
    fun click_botonGuardar(){
        buttonGuardar.setOnClickListener(){
            Toast.makeText(applicationContext, "Guardado en galería", Toast.LENGTH_SHORT).show()
        }
    }
}
