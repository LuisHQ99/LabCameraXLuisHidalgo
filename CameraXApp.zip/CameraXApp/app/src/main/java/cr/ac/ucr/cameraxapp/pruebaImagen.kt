package cr.ac.ucr.cameraxapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class pruebaImagen : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_prueba_imagen)
    }
}
